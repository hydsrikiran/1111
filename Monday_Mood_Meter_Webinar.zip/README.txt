Monday Mood Meter - AIML ZG519 NLP Applications webinar (BITS Pilani WILP)

Files
  Monday_Mood_Meter_INSTRUCTOR.ipynb - your copy: talking points, quiz answers, exercise solution (keep on your second screen)
  Monday_Mood_Meter_STUDENT.ipynb    - share this on screen and with students: all questions, no answers
  data/employee_reviews.csv          - 67,529 public Glassdoor reviews (Google, Amazon, Facebook, Apple, Microsoft, Netflix; 2008-2018)
  requirements.txt

Setup (once)
  python -m venv .venv
  .venv\Scripts\activate   (Windows)   |   source .venv/bin/activate   (macOS/Linux)
  pip install -r requirements.txt
  Open the folder in VS Code -> open a notebook -> Select Kernel -> .venv

Night before
  In the config cell set PREFETCH = True, run all once (~1 GB of models), then set it back to False.
  Optional local LLM: install Ollama, then `ollama pull llama3.2:3b`.

During the session
  Paste anonymous chat replies into LIVE_MOOD_START (start) and LIVE_MOOD_END (Part 10).
  Fill CLASS_GUESSES (Part 1) and CLASS_ANSWERS (Part 7) with the class's chat answers.
